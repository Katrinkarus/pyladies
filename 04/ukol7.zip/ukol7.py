rodne_cislo = input("Zadaj rodne cislo: ")
datum = rodne_cislo[0:6]
poradie = rodne_cislo[7:11]
rok = datum[0:2]
mesiac = datum[2:4]
pohlavie = int(rodne_cislo[2])
den = datum[4:6]

# # A
if rodne_cislo == datum + "/" + poradie:
    print(True)
if rodne_cislo != datum + "/" + poradie:
    print("Zle zadane rodne cislo!")

# # B
x = int(datum + poradie)
if x % 11 == 0:
    print("Cislo je delitelne 11.")
else:
    print("Cislo nie je delitelne 11. Zle rodne cislo!")


## C
if pohlavie == 5:
    print("Datum narodenie je: ", den, int(mesiac) - 50, rok)
    if pohlavie == 6:
        print("Datum narodenie je: ", den, int(mesiac) - 50, rok)
else:
    print("Datum narodenia je: ", den, mesiac, rok)
    
# # D
if pohlavie == 5:
    print("Zena")
    if pohlavie == 6:
        print("Zena")
else:
    print("Muz")






 